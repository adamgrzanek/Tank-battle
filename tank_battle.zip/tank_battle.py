#-*- coding: utf-8 -*-

import pygame
import random
import datetime
import os, sys
from pygame import mixer


def resource_path(relative_path):
    try:
    # PyInstaller creates a temp folder and stores path in MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


# rozpocznij program
pygame.init()
clock = pygame.time.Clock()

screen_size = 600

# stwórz ekran gry
screen = pygame.display.set_mode((screen_size+100, screen_size)) # +100 na info area


# nazwa gry
pygame.display.set_caption("Tank Battle")


# ikona gry
icon_url = resource_path("assets/tank.png")
icon = pygame.image.load(icon_url)
pygame.display.set_icon(icon)


image_size = 64 # 64px


# dzwiek tla
music_url = resource_path('sounds/background.mp3')
mixer.music.load(music_url)
mixer.music.play(-1) # -1 : odtwarzany w nieskonczonosc;  (1-raz, 2-dwa razy,....)
mixer.music.set_volume(0.3)  # 0-1


class Player:

    player_speed = 2

    def __init__(self):
        self.pos_x = 300
        self.pos_y = 300
        self.fire_state = 'ready'
        self.reload_time = 900000  # microseconds  1000000 = 1s
        self.life = 100
        #self.img = pygame.image.load('assets/tank.png')
        self.img = pygame.image.load(resource_path('assets/tank.png'))


    def move(self, m_x=0, m_y=0):
        self.pos_x += m_x
        self.pos_y += m_y


    def draw(self, angle=0):
        image = pygame.transform.rotate(self.img, angle)
        screen.blit(image, (player_1.pos_x-image_size/2, player_1.pos_y-image_size/2))


player_1 = Player()
angle = 0


class Enemy:

    def __init__(self):
        self.speed = 1
        self.enemy_pos_x = random.randrange(image_size/2, screen_size - image_size/2)
        self.enemy_pos_y = random.randrange(image_size/2, screen_size - image_size/2)
        self.fire_state = 'ready'
        self.reload_time = 500000 # microseconds
        self.bullet_speed = 5
        self.enemy_img = pygame.image.load(resource_path('assets/tank_2.png'))
        self.life = 100


    def follow(self, x, y):  # follow player.pos_x, player.pos_y

        global enemy_angle

        if x > self.enemy_pos_x:
            self.enemy_pos_x += self.speed
            enemy_angle = -90
        elif x < self.enemy_pos_x:
            self.enemy_pos_x -= self.speed
            enemy_angle = 90
        elif y > self.enemy_pos_y:
            self.enemy_pos_y += self.speed
            enemy_angle = 180
        elif y < self.enemy_pos_y:
            self.enemy_pos_y -= self.speed
            enemy_angle = 0

    def draw_enemy(self, enemy_angle):
        enemy_image = pygame.transform.rotate(self.enemy_img, enemy_angle)
        screen.blit(enemy_image, (self.enemy_pos_x-image_size/2, self.enemy_pos_y-image_size/2))


    def check_pos(self):
        # if close to player -> player life drops
        distance = ((self.enemy_pos_x - player_1.pos_x) ** 2 + (self.enemy_pos_y - player_1.pos_y) ** 2) ** (
                    1 / 2)
        if distance < 50:
            player_1.life -= 1


    def shot(self):
        global enemy_start_fire

        if self.fire_state == 'ready':
            if self.enemy_pos_x == player_1.pos_x or self.enemy_pos_y == player_1.pos_y:
                e_b = Bullet(self.enemy_pos_x, self.enemy_pos_y, self.bullet_speed, enemy_angle, self)
                self.fire_state = 'reload'
                enemy_start_fire = datetime.datetime.now()


enemy_1 = Enemy()


class Bullet:

    bullet_list = []

    def __init__(self, bullet_x, bullet_y, bullet_speed, bullet_angle, who):
        self.bullet_x = bullet_x
        self.bullet_y = bullet_y
        self.bullet_speed = bullet_speed
        self.bullet_angle = bullet_angle
        self.who = who
        Bullet.bullet_list.append(self)


    def attack(self, x, y):
        pygame.draw.circle(screen, (255, 0, 0), (x, y), 3)


    def del_obj(self):
        Bullet.bullet_list.remove(self)
        del self


    def collision(self):
        # distance = ((x2 - x1) ^ 2 + (y2 - y1) ^ 2) ^ (1 / 2)  # distance between 2 point

        if isinstance(self.who, Player):
            distance = ((enemy_1.enemy_pos_x - self.bullet_x) ** 2 + (enemy_1.enemy_pos_y - self.bullet_y) ** 2) ** (1 / 2)
            if distance < 10:
                enemy_1.life -= 10
                Bullet.del_obj(self)

        if isinstance(self.who, Enemy):
            distance = ((player_1.pos_x - self.bullet_x) ** 2 + (player_1.pos_y - self.bullet_y) ** 2) ** (1 / 2)
            if distance < 30:
                player_1.life -= 10
                Bullet.del_obj(self)


# czcianka
font_url = resource_path('fonts/RobotoMono-Bold.ttf')
font = pygame.font.Font(font_url, 20)  # czcionka z  https://fonts.google.com/
font_r = pygame.font.Font(font_url, 15)


def draw_info_area():

    # extra background
    pygame.draw.rect(screen, (100, 100, 100), (screen_size, 0, screen_size + 100, screen_size))

    # level
    level_text = font_r.render(f"Level: {level}", True, (0, 0, 0))  # renderowanie
    screen.blit(level_text, (screen_size + 15, 100))

    # enemy bullet speed
    font_b = pygame.font.Font(font_url, 10)
    bullet_speed_text = font_b.render(f"Bullet speed: {enemy_1.bullet_speed}", True, (0, 0, 0))  # renderowanie
    screen.blit(bullet_speed_text, (screen_size + 3, 120))

    # enemy info
    enemy_text = font.render("Enemy", True, (0, 0, 0)) # renderowanie
    enemy_life = font.render(f"{enemy_1.life}%", True, (0, 0, 0)) # renderowanie
    screen.blit(enemy_text, (screen_size+15, 20))
    screen.blit(enemy_life, (screen_size+20, 45))

    # player info
    player_text = font.render("Player", True, (0, 0, 0))  # renderowanie
    player_life = font.render(f"{player_1.life}%", True, (0, 0, 0))  # renderowanie
    screen.blit(player_text, (screen_size + 10, 520))
    screen.blit(player_life, (screen_size + 20, 545))


def game_over():
    global game_state, angle

    if player_1.life <= 0:
        game_state = "over"
        Bullet.bullet_list.clear()
        end = font.render("GAME OVER", True, (0, 0, 0))  # renderowanie
        screen.blit(end, (250, 270))
        angle = 0
        player_1.img = pygame.image.load('assets/explosion.png')
        enemy_1.enemy_pos_x=1000
        enemy_1.enemy_pos_y=1000

        reset1 = font_r.render("press 'r'", True, (0, 0, 0))  # renderowanie
        reset2 = font_r.render("to start", True, (0, 0, 0))  # renderowanie
        reset3 = font_r.render("new game", True, (0, 0, 0))  # renderowanie
        screen.blit(reset1, (screen_size + 10, 280))
        screen.blit(reset2, (screen_size + 10, 300))
        screen.blit(reset3, (screen_size + 10, 320))


def next_level():
    global game_state, enemy_angle, level

    if enemy_1.life <= 0:
        game_state = "next"
        next_level = font.render("CONGRATULATIONS! You go to the next level", True, (0, 0, 0))  # renderowanie
        press_r = font_r.render("press 's'", True, (0, 0, 0))  # renderowanie
        screen.blit(next_level, (50, 270))
        screen.blit(press_r, (screen_size + 10, 280))

        enemy_angle = 0
        enemy_1.enemy_img = pygame.image.load(resource_path('assets/explosion.png'))
        enemy_1.fire_state = 'ready'


def new_game():
    global game_state, level
    game_state = "play"

    player_1.pos_x = 300
    player_1.pos_y = 300
    player_1.life = 100
    player_1.img = pygame.image.load(resource_path('assets/tank.png'))

    enemy_1.life = 100
    enemy_1.enemy_img = pygame.image.load(resource_path('assets/tank_2.png'))
    enemy_1.fire_state = 'ready'

    enemy_1.enemy_pos_x = random.randrange(image_size / 2, screen_size - image_size / 2)
    enemy_1.enemy_pos_y = random.randrange(image_size / 2, screen_size - image_size / 2)


# dzwieki
shot_sound_url = resource_path('sounds/shot.wav')


game_state = "play"
level = 1

global start_fire
start_fire = datetime.datetime.now()
enemy_start_fire = datetime.datetime.now()


running = True
while running:

    # tło gry
    screen.fill((120, 180, 55))  # Red Green Blue 0-255     https://www.color-hex.com/
    draw_info_area()

    for event in pygame.event.get():    # pobiera wszystkie wydarzenia, które wydarzają się w konkretnym momencie (klawisz, mysz)
        if event.type == pygame.QUIT:   # jesli wydarzenie to naciśniecie "zamknij" ->
            running = False             # -> kończy pętle

    keys = pygame.key.get_pressed()  # wciśnięte klawisze

    if game_state == "over":
        Bullet.bullet_list.clear()
        if keys[pygame.K_r]:
            new_game()
            enemy_1.speed = 1
            enemy_1.bullet_speed = 5
            level = 1

    elif game_state == "next":
        Bullet.bullet_list.clear()
        if keys[pygame.K_s]:
            level += 1
            enemy_1.bullet_speed += 1
            new_game()

    elif game_state == "play":

        if keys[pygame.K_LEFT]:
            player_1.move(m_x=-Player.player_speed)
            angle = 90

        elif keys[pygame.K_RIGHT]:
            player_1.move(m_x=Player.player_speed)
            angle = -90

        elif keys[pygame.K_UP]:
            player_1.move(m_y=-Player.player_speed)
            angle = 0

        elif keys[pygame.K_DOWN]:
            player_1.move(m_y=Player.player_speed)
            angle = 180

        if keys[pygame.K_SPACE]:  # spr czy spacja jest wcisnieta
            if player_1.fire_state == 'ready':
                shot_sound = mixer.Sound(shot_sound_url)
                shot_sound.play()
                bullet_angle = angle
                start_fire = datetime.datetime.now()
                Bullet(player_1.pos_x, player_1.pos_y, 5, bullet_angle, player_1)
                player_1.fire_state = 'reload'
                for i in Bullet.bullet_list:
                    i.attack(player_1.pos_x, player_1.pos_y)

        enemy_1.follow(player_1.pos_x, player_1.pos_y)
        enemy_1.shot()
        enemy_1.check_pos()

    player_1.draw(angle)
    enemy_1.draw_enemy(enemy_angle)

    # area limit
    if player_1.pos_x <= image_size/2:
        player_1.pos_x = image_size/2
    elif player_1.pos_x >= screen_size - image_size/2:
        player_1.pos_x = screen_size - image_size/2
    if player_1.pos_y <= image_size/2:
        player_1.pos_y = image_size/2
    elif player_1.pos_y >= screen_size - image_size/2:
        player_1.pos_y = screen_size - image_size/2


    # player reload time
    f_time = datetime.datetime.now()
    #if (f_time - start_fire).seconds >= player_1.reload_time:
    if (f_time - start_fire).microseconds >= player_1.reload_time:
        player_1.fire_state = 'ready'

    # enemy reload time
    if (f_time - enemy_start_fire).microseconds >= enemy_1.reload_time:
        enemy_1.fire_state = 'ready'

    # draw all shooted bullets
    for b in Bullet.bullet_list:
        if b.bullet_angle == 0:
            b.bullet_y -= b.bullet_speed
        elif b.bullet_angle == 180:
            b.bullet_y += b.bullet_speed
        elif b.bullet_angle == 90:
            b.bullet_x -= b.bullet_speed
        elif b.bullet_angle == -90:
            b.bullet_x += b.bullet_speed


        b.attack(b.bullet_x, b.bullet_y)
        b.collision()

        # del bullet if out of screen
        if b.bullet_x < 0 or b.bullet_x > screen_size:
            b.del_obj()
        if b.bullet_y < 0 or b.bullet_y > screen_size:
            b.del_obj()


    game_over()
    next_level()

    pygame.display.update()
    clock.tick(40)  # 40 kaltek na sekund


